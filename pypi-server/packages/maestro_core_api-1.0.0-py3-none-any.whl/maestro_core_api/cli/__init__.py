"""UTCP CLI module."""

from .utcp_cli import cli

__all__ = ["cli"]